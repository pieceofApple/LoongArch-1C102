#ifndef _SOC_HPET_H
#define _SOC_HPET_H

#ifdef __cplusplus
extern "C" {
#endif

void timer_irq();
void timer_interrupt();

#ifdef __cplusplus
}
#endif

#endif // _SOC_HPET_H
