
#define X_MAX_PIXEL	        168
#define Y_MAX_PIXEL	        128


