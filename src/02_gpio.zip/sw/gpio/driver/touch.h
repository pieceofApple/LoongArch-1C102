/*
 * touch.h
 *
 *  Created on: 2023年6月5日
 *      Author: j
 */

#ifndef DRIVER_TOUCH_H_
#define DRIVER_TOUCH_H_

//按键测试
void ls102_touch_test();


#endif /* DRIVER_TOUCH_H_ */
